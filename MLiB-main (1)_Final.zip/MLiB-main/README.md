This repository has been developed as support material for the course Machine Learning in Biomedicine of the Biomedical Engineering degree at the CEU San Pablo University.

The code found in the repository is distributed under the Apache 2.0 license. Any feedback/corrections/improvements are welcome.